//
//  ViewController.swift
//  20210302
//
//  Created by 彭少麒 on 2021/3/2.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDataSource, UIPickerViewDelegate {
    
    let location = ["台北","新北","桃園","台中","台南","高雄"]
    let temperature = ["30°C","31°C","32°C","33°C","34°C"]
        
    
    @IBOutlet var locationTextField: UITextField!
    @IBOutlet var temperatureTextField: UITextField!
    
    var locationPickerView = UIPickerView()
    var temperaturePickerView = UIPickerView()
    
    
    
    
    //觸摸其它地方關閉編輯
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    
    
    
//    var a,b:String? // 用來存地點與溫度，下面有一個函數會用到


    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //讓 Text Field 的輸入方式改為 Picker View。

            locationPickerView.dataSource = self
            locationPickerView.delegate = self
            
            temperaturePickerView.dataSource = self
            temperaturePickerView.delegate = self
            
            locationTextField.inputView = locationPickerView
            temperatureTextField.inputView = temperaturePickerView
        // Do any additional setup after loading the view.
        
        
    }
    
    
    
    //兩個 Picker View 的三階段對話函數，以及選擇後填入對應 Text Field。
    
    //呈現幾個滾輪
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
            return 1
    }
        
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            if pickerView == locationPickerView {
                return location.count
            }
            if pickerView == temperaturePickerView {
                return temperature.count
            }
            return 0
            
     }
        
    
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            if pickerView == locationPickerView {
                return location[row]
            }
            if pickerView == temperaturePickerView {
                return temperature[row]
            }
            return nil
     }


    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            if pickerView == locationPickerView {
                locationTextField.text = location[row]
            }
            if pickerView == temperaturePickerView {
                temperatureTextField.text = temperature[row]
            }
                    
     }

}

